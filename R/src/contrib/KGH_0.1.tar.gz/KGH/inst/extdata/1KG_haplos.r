require(gaston.utils)

# la carte
MAP <- read.table("map.txt", sep = "\t", header = TRUE)

x <- read.vcf.1000genomes("~/DATA/1000genomes/", MAP, super.populations="EUR", haplotypes = TRUE)
x <- set.dist(x, HumanGeneticMap::genetic.map.b37)

write.bed.matrix(x, "1KG_haplos", fam = NULL, bim = NULL)

