#' @export
means <- function(x) cumsum(x) / seq_along(x)
