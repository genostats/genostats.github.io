
#' Metropolis-Hastings algorithm
#'
#' @param Pi The density to be sampled, or its log (see parameter \code{log}).
#' @param x The starting point
#' @param B Number of points sampled
#' @param Omega Variance or matrix of variance-covariance of the proposal
#' @param burn Length of burn-in
#' @param thin Thinning parameter
#' @param log If \code{TRUE}, \code{Pi} is the log of the density to be sampled
#'
#' @details \code{Pi} is a function that takes a single parameter, a vector of length n and returns a scalar.
#' The starting point \code{x} has length n. A Gaussian proposal with variance matrix \code{Omega} is used, if
#' \code{Omega} is a \eqn{n \times n}{n x n} matrix. If \code{Omega} is a scalar, a diagonal matrix with
#' this value will be used.
#'
#' @return A \eqn{B \times n}{B x n} matrix, each line corresponding to a sample.
#' @export
#'
#' @examples
#' # The function to sample
#' PI <- function(x) (1 + x[1]**2 + x[1]*x[2] + x[2]**2)^(-3)
#' A <- Metropolis(PI, c(0,0), 1e5, 0.4)
#' hist(A[,1], breaks = 100, xlim= c(-4,4), freq=FALSE)
#' # Using the log insteadd
#' logPI <- function(x) log(PI(x))
#' B <- Metropolis(logPI, c(0,0), 1e5, 0.4, log = TRUE)
#' hist(B[,1], breaks = 100, xlim= c(-4,4), freq=FALSE)

Metropolis <- function(Pi, x, B, Omega = 1, burn = 0, thin = 1, log = FALSE) {
  n <- length(x);
  if(length(Omega) == 1 & n > 1) {
    Omega <- diag(n)*Omega
  }
  CholOmega <- chol(Omega)
  R <- matrix(0, nrow = B, ncol = n);
  if(thin < 1) thin <- 1;
  b <- 0;
  pi.x <- Pi(x);
  if(is.na(pi.x) | (!log & pi.x == 0) | (log & pi.x == -Inf))
    stop("The likelihood is null or undefined at starting point")
  k <- 1;
  while(b <= B) {
    y <- x + CholOmega %*% rnorm(n)
    pi.y  <-  Pi(y);
    if(is.na(pi.y)) {
      if(log)
        pi.y <- -Inf
      else
        pi.y <- 0
    }

    if(log)
      test <- (runif(1) < exp(pi.y - pi.x))
    else
      test <- (runif(1) * pi.x < pi.y)
    if(test) {
      x <- y;
      pi.x <- pi.y;
    }
    if(k > burn & (k %% thin) == 0) {
      R[b,] <- x;
      b <- b+1;
    }
    k <- k+1;
  }
  return(R);
}

